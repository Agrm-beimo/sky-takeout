package com.sky.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SalesTop10Statistic {
    private String name;//商品名称
    private Integer total;//销售数量
}
