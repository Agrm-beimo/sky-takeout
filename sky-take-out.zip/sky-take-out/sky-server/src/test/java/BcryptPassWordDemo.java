import org.junit.jupiter.api.Test;
import org.springframework.util.DigestUtils;

public class BcryptPassWordDemo {

    @Test
    public void test1(){
        String password = "123456";

        String s = DigestUtils.md5DigestAsHex(password.getBytes());
        System.out.println("原始密码：" + password);
        System.out.println("加密后的密码：" + s);
        System.out.println("加密后的密码长度：" + s.length());

        System.out.println("两次密码是否一致：" + password.equals(s));
    }

}
