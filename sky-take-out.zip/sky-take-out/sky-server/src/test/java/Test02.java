import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.*;

public class Test02 {

    @Test
    public void test03() {
        LocalDate begin = LocalDate.parse("2025-05-05");
        LocalDate end = LocalDate.parse("2025-05-05");
        StringBuffer date = new StringBuffer();
        while (begin.isBefore(end)){
            System.out.println(begin);
            date.append(begin);
            date.append(",");
            begin = begin.plusDays(1);
        }
        date.append(LocalDate.now());

        System.out.println(date);
    }

}
