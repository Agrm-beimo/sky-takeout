import org.junit.jupiter.api.Test;

public class Test01 {

    public static void main(String[] args) {
        Runnable run1 = ()->{
            easyTest();
        };
        Thread t1 = new Thread(run1);
        Thread t2 = new Thread(run1);

        t1.setName("T1");
        t2.setName("T2");

        t1.start();
        t2.start();
    }


    public static synchronized void easyTest(){
        System.out.println(Thread.currentThread().getName() + "-----开始");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(Thread.currentThread().getName() + "-----结束");
    }
}
