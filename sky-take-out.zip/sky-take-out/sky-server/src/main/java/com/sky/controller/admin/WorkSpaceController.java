package com.sky.controller.admin;

import com.sky.result.Result;
import com.sky.service.WorkSpaceService;
import com.sky.vo.BusinessDataVO;
import com.sky.vo.DishOverViewVO;
import com.sky.vo.OrderOverViewVO;
import com.sky.vo.SetmealOverViewVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

@RestController
@Slf4j
@Api(tags = "工作台相关接口")
@RequestMapping("admin/workspace")
public class WorkSpaceController {

    @Autowired
    private WorkSpaceService workSpaceService;


    /**
     * 查询今日运营数据
     * @return
     */
    @GetMapping("businessData")
    @ApiOperation("查询今日运营数据")
    public Result<BusinessDataVO> businessData(){
        log.info("查询今日运营数据");
        BusinessDataVO businessDataVO = workSpaceService.businessData(LocalDate.now(),LocalDate.now().plusDays(1));
        return Result.success(businessDataVO);
    }


    /**
     * 查询套餐总览
     * @return
     */
    @GetMapping("overviewSetmeals")
    @ApiOperation("查询套餐总览")
    public Result<SetmealOverViewVO> overviewSetmeals(){
        log.info("查询套餐总览");
        SetmealOverViewVO setmealOverViewVO = workSpaceService.overviewSetmeals();
        return Result.success(setmealOverViewVO);
    }


    /**
     * 查询菜品总览
     * @return
     */
    @GetMapping("overviewDishes")
    @ApiOperation("查询菜品总览")
    public Result<DishOverViewVO> overviewDishes(){
        log.info("查询菜品总览");
        DishOverViewVO dishOverViewVO = workSpaceService.overviewDishes();
        return Result.success(dishOverViewVO);
    }


    /**
     * 查询订单总览
     * @return
     */
    @GetMapping("overviewOrders")
    @ApiOperation("查询订单总览")
    public Result<OrderOverViewVO> overviewOrders(){
        log.info("查询订单总览");
        OrderOverViewVO orderOverViewVO = workSpaceService.overviewOrders();
        return Result.success(orderOverViewVO);
    }

}
