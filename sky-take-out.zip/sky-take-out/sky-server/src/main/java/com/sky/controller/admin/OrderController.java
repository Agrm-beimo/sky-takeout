package com.sky.controller.admin;

import com.sky.dto.OrdersCancelDTO;
import com.sky.dto.OrdersConfirmDTO;
import com.sky.dto.OrdersPageQueryDTO;
import com.sky.dto.OrdersRejectionDTO;
import com.sky.result.PageResult;
import com.sky.result.Result;
import com.sky.service.OrderService;
import com.sky.vo.OrderStatisticsVO;
import com.sky.vo.OrderVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController("adminController")
@RequestMapping("/admin/order")
@Slf4j
@Api(tags = "订单管理接口")
public class OrderController {


    @Autowired
    private OrderService orderService;


    /**
     * 订单管理查询
     * @param orderPageQueryDTO
     * @return
     */
    @GetMapping("conditionSearch")
    @ApiOperation("订单管理查询")
    public Result<PageResult> orderList(OrdersPageQueryDTO orderPageQueryDTO){
        log.info("订单管理查询:{}",orderPageQueryDTO);
        PageResult pageResult = orderService.orderList(orderPageQueryDTO);
        return Result.success(pageResult);
    }


    /**
     * 订单统计
     * @return
     */
    @GetMapping("statistics")
    @ApiOperation("订单统计")
    public Result<OrderStatisticsVO> statistics(){
        log.info("统计各类订单数目");
        OrderStatisticsVO orderStatisticsVO = orderService.statistics();
        return Result.success(orderStatisticsVO);
    }


    /**
     * 查询订单详细信息
     * @param id
     * @return
     */
    @GetMapping("details/{id}")
    @ApiOperation("查询订单详细信息")
    public Result<OrderVO> details(@PathVariable Long id){
        log.info("查询订单详细信息:{}",id);
        OrderVO orderVO = orderService.details(id);
        return Result.success(orderVO);
    }


    /**
     * 确认订单
     * @param orderConfirmDTO
     * @return
     */
    @PutMapping("confirm")
    @ApiOperation("确认订单")
    public Result confirmOrder(@RequestBody OrdersConfirmDTO orderConfirmDTO){
        log.info("确认订单:{}",orderConfirmDTO);
        orderService.confirmOrder(orderConfirmDTO);
        return Result.success();
    }


    /**
     * 派送订单
     * @param id
     * @return
     */
    @PutMapping("delivery/{id}")
    @ApiOperation("派送订单")
    public Result deliverOrder(@PathVariable Long id){
        log.info("派送订单:{}",id);
        orderService.deliverOrder(id);
        return Result.success();
    }


    /**
     * 完成订单
     * @param id
     * @return
     */
    @PutMapping("complete/{id}")
    @ApiOperation("完成订单")
    public Result completeOrder(@PathVariable Long id){
        log.info("完成订单:{}",id);
        orderService.completeOrder(id);
        return Result.success();
    }


    /**
     * 取消订单
     * @param orderCancelDTO
     * @return
     */
    @PutMapping("cancel")
    @ApiOperation("取消订单")
    public Result cancelOrder(@RequestBody OrdersCancelDTO orderCancelDTO){
        log.info("取消订单:{}",orderCancelDTO);
        orderService.cancelOrder(orderCancelDTO);
        return Result.success();
    }


    /**
     * 拒单
     * @param orderRejectionDTO
     * @return
     */
    @PutMapping("rejection")
    @ApiOperation("拒单")
    public Result rejectOrder(@RequestBody OrdersRejectionDTO orderRejectionDTO){
        log.info("订单拒单:{}",orderRejectionDTO);
        orderService.rejectOrder(orderRejectionDTO);
        return Result.success();
    }

}
