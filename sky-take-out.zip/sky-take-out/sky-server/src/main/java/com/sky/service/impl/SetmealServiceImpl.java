package com.sky.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.sky.constant.MessageConstant;
import com.sky.constant.StatusConstant;
import com.sky.dto.SetmealDTO;
import com.sky.dto.SetmealPageQueryDTO;
import com.sky.entity.Dish;
import com.sky.entity.Setmeal;
import com.sky.entity.SetmealDish;
import com.sky.exception.DeletionNotAllowedException;
import com.sky.mapper.DishMapper;
import com.sky.mapper.SetmealDishMapper;
import com.sky.mapper.SetmealMapper;
import com.sky.result.PageResult;
import com.sky.service.SetmealService;
import com.sky.vo.DishVO;
import com.sky.vo.SetmealVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class SetmealServiceImpl implements SetmealService {

    @Autowired
    private SetmealMapper setmealMapper;

    @Autowired
    private SetmealDishMapper setmealDishMapper;

    @Autowired
    private DishMapper dishMapper;

    /**
     * 套餐分页查询
     * @param setmealPageQueryDTO 分页查询参数
     * @return page
     */
    @Override
    public PageResult pageQuery(SetmealPageQueryDTO setmealPageQueryDTO) {
        //pageHelper
        PageHelper.startPage(setmealPageQueryDTO.getPage(),setmealPageQueryDTO.getPageSize());
        Page<Setmeal> pages = setmealMapper.pageQuery(setmealPageQueryDTO);

        return new PageResult(pages.getTotal(),pages.getResult());
    }


    /**
     * 新增套餐信息
     * @param setmealDTO 套餐信息
     */
    @Override
    @Transactional
    public void saveWithDish(SetmealDTO setmealDTO) {
        //操作两张表 setmeal 和 setmeal_dish
        Setmeal setmeal = new Setmeal();
        BeanUtils.copyProperties(setmealDTO,setmeal);
        setmeal.setStatus(StatusConstant.DISABLE);
        //插入套餐信息
        setmealMapper.insert(setmeal);
        //获得主键套餐id
        Long id = setmeal.getId();

        //插入套餐菜品关联表
        List<SetmealDish> setmealDishes = setmealDTO.getSetmealDishes();
        if(!(setmealDishes.isEmpty())){
            setmealDishes.forEach(setmealDish ->{
                setmealDish.setSetmealId(id);
            });
            setmealDishMapper.insertBatch(setmealDishes);
        }

    }

    /**
     * 更改套餐信息
     * @param setmealDTO 套餐信息
     */
    @Override
    @Transactional
    public void update(SetmealDTO setmealDTO) {
        //操作两张表setmeal和setmeal_dish
        Setmeal setmeal = new Setmeal();
        BeanUtils.copyProperties(setmealDTO,setmeal);
        setmeal.setStatus(StatusConstant.DISABLE);
        //更新setmeal表记录
        setmealMapper.update(setmeal);

        //拿到id和菜品关联集合
        Long id = setmeal.getId();

        List<SetmealDish> setmealDishes = setmealDTO.getSetmealDishes();
        //删除setmeal_dish表中的记录 再插入
        setmealDishMapper.deleteBySetmealIdBatch(Collections.singletonList(id));

        if(!(setmealDishes.isEmpty())){
            setmealDishes.forEach(setmealDish -> {
                setmealDish.setSetmealId(id);
            });
            setmealDishMapper.insertBatch(setmealDishes);
        }

    }

    /**
     * 根据id查询套餐信息
     * @param id 套餐id
     * @return SetmealVO
     */
    @Override
    public SetmealVO getByIdWithDish(Long id) {
        SetmealVO setmealVO = new SetmealVO();
        //查两张表
        Setmeal setmeal = setmealMapper.getById(id);

        List<SetmealDish> setmealDishes = setmealDishMapper.getBySetmealId(id);

        BeanUtils.copyProperties(setmeal,setmealVO);
        setmealVO.setSetmealDishes(setmealDishes);
        return setmealVO;
    }

    /**
     * 更改套餐起售状态
     * @param status 状态
     */
    @Override
    public void startOrStop(Integer status,Long id) {
        //判断套餐内是否有未起售的菜品
        if (status == StatusConstant.ENABLE){
            List<Dish> dishes =dishMapper.getBySetmealId(id);
            if(!(dishes.isEmpty())){
                dishes.forEach(dish->{
                    if(dish.getStatus() == StatusConstant.DISABLE){
                        throw new DeletionNotAllowedException(MessageConstant.SETMEAL_ENABLE_FAILED);
                    }
                });
            }
        }

        Setmeal setmeal = new Setmeal();
        setmeal.setId(id);
        setmeal.setStatus(status);
        setmealMapper.update(setmeal);
    }


    /**
     * 批量删除套餐信息
     * @param ids 套餐id
     */
    @Override
    @Transactional
    public void deleteBatch(List<Long> ids) {
        //删除两张表中的信息 setmeal 和 setmeal_dish
        //起售状态下不能删除
        ids.forEach(id -> {
            Setmeal setmeal = setmealMapper.getById(id);
            //如果是在售状态
            if(setmeal.getStatus() == StatusConstant.ENABLE){
                throw new DeletionNotAllowedException(MessageConstant.SETMEAL_ON_SALE);
            }
        });

        setmealMapper.deleteBatch(ids);

        setmealDishMapper.deleteBySetmealIdBatch(ids);
    }

    /**
     * 根据条件查询套餐
     * @param setmeal
     * @return
     */
    @Override
    public List<Setmeal> list(Setmeal setmeal) {
        List<Setmeal> list = setmealMapper.list(setmeal);
        return list;
    }


    /**
     * 根据套餐id查询菜品
     * @param setmealId
     * @return
     */
    @Override
    public List<DishVO> getDishItemById(Long setmealId) {
        return setmealMapper.getDishItemById(setmealId);
    }
}
