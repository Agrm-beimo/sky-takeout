package com.sky.controller.user;

import com.sky.constant.StatusConstant;
import com.sky.entity.Dish;
import com.sky.result.Result;
import com.sky.service.DishService;
import com.sky.vo.DishVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController("userDishController")
@Slf4j
@Api(tags = "用户端菜品相关接口")
@RequestMapping("/user/dish")
public class DishController {

    public static final Long Cache_Out_Time = 60 * 30L;

    @Autowired
    private DishService dishService;

    @Autowired
    private RedisTemplate redisTemplate;

    /**
     * 根据分类id查询菜品
     * @param categoryId
     * @return
     */
    @GetMapping("/list")
    @ApiOperation("根据分类id查询菜品")
    @Cacheable(cacheNames = "dishCache",key = "#categoryId")
    public Result<List<DishVO>> list(Long categoryId){
        log.info("根据分类id查询菜品:{}",categoryId);
//        //构造key   dish_id
//        String key = "dish_" + categoryId;
//
//        //查询Redis数据库中是否有餐品
//        List<DishVO> list = (List<DishVO>) redisTemplate.opsForValue().get(key);
//
//        if (list != null && list.size() > 0){
//            //如果有，则直接返回
//            return Result.success(list);
//        }
//
//        //如果没有，则查询数据库
        Dish dish = new Dish();
        dish.setCategoryId(categoryId);
        // 查询状态为起售中的菜品
        dish.setStatus(StatusConstant.ENABLE);

        List<DishVO> list = dishService.listWithFlavor(dish);

        //将查询到的数据保存到Redis数据库中
        //redisTemplate.opsForValue().set(key,list,Cache_Out_Time);

        return Result.success(list);
    }


}
