package com.sky.mapper;

import com.sky.dto.GoodsSalesDTO;
import com.sky.entity.OrderDetail;
import com.sky.entity.SalesTop10Statistic;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDate;
import java.util.List;

@Mapper
public interface OrderDetailMapper {

    /**
     * 批量插入订单明细数据
     * @param orderDetails
     */
    void insertBatch(List<OrderDetail> orderDetails);

    /**
     * 根据订单号查询订单明细
     * @param id
     * @return
     */
    @Select("select * from order_detail where order_id = #{id}")
    List<OrderDetail> getByOrderId(Long id);


    /**
     * 查询销量排名top10
     * @param begin
     * @param end
     * @return
     */
    @Select("SELECT od.name as name , sum(od.number) as total FROM order_detail od,orders o WHERE od.order_id = o.id and status = 5 \n" +
            "and o.delivery_time BETWEEN #{begin} AND #{end} GROUP BY name order by total DESC LIMIT 10;")
    List<GoodsSalesDTO> getTop10Sales(LocalDate begin, LocalDate end);
}
