package com.sky.service.impl;

import com.sky.entity.*;
import com.sky.mapper.DishMapper;
import com.sky.mapper.OrderMapper;
import com.sky.mapper.SetmealMapper;
import com.sky.mapper.UserMapper;
import com.sky.service.SetmealService;
import com.sky.service.WorkSpaceService;
import com.sky.vo.BusinessDataVO;
import com.sky.vo.DishOverViewVO;
import com.sky.vo.OrderOverViewVO;
import com.sky.vo.SetmealOverViewVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class WorkSpaceServiceImpl implements WorkSpaceService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private SetmealMapper setmealMapper;

    @Autowired
    private DishMapper dishMapper;

    /**
     * 查询今日运营数据
     * @return
     */
    @Override
    public BusinessDataVO businessData(LocalDate beginDate,LocalDate endDate) {
        // 查询用户数据
        List<UserStatistic> userList = userMapper.getUserListByDate(beginDate,endDate);
        Integer newUsers = 0;
        if (userList.size() > 0){
            for (UserStatistic userStatistic : userList) {
                newUsers += userStatistic.getAmount().intValue();
            }
        }

        //  查询订单数据
        List<OrderStatistic> totalOrderList = orderMapper.getOrderListByDateAndStatus(beginDate,endDate,null);
        List<OrderStatistic> validOrderList = orderMapper.getOrderListByDateAndStatus(beginDate,endDate, Orders.COMPLETED);

        Integer validOrderCount = 0;
        Integer totalOrderCount = 0;
        Double orderCompletionRate = 0.0;

        if(totalOrderList.size() > 0){
            for (OrderStatistic orderStatistic : totalOrderList) {
                totalOrderCount += orderStatistic.getAmount().intValue();
            }
        }

        if(validOrderList.size() > 0){
            for (OrderStatistic orderStatistic : validOrderList) {
                validOrderCount += orderStatistic.getAmount().intValue();
            }
            orderCompletionRate = Math.round(validOrderCount * 100.0 / totalOrderCount) / 100.0;
        }

        //获取当天营业额
        List<TurnoverStatistic> totalTurnover = orderMapper.getDayAndAmountByDate(beginDate, endDate);
        Double turnover = 0.0;
        Double unitPrice = 0.0;
        if(totalTurnover.size() > 0){
            for (TurnoverStatistic turnoverStatistic : totalTurnover) {
                turnover += turnoverStatistic.getAmount().doubleValue();
            }
            if(validOrderCount != 0){
                //四舍五入保留小数点后两位
                unitPrice = Math.round(turnover / validOrderCount * 100) / 100.0;
            }
        }

        return BusinessDataVO.builder()
                .newUsers(newUsers)
                .validOrderCount(validOrderCount)
                .orderCompletionRate(orderCompletionRate)
                .turnover(turnover)
                .unitPrice(unitPrice).build();
    }


    /**
     * 套餐总览
     * @return
     */
    @Override
    public SetmealOverViewVO overviewSetmeals() {
        // 查询已停售的套餐
        List<Setmeal> discontinuedSetmealList = setmealMapper.getByStatus(Setmeal.DISCONTINUED);

        // 查询已起售的套餐
        List<Setmeal> soldSetmealList = setmealMapper.getByStatus(Setmeal.SOLD);


        return SetmealOverViewVO.builder()
                .discontinued(discontinuedSetmealList.size())
                .sold(soldSetmealList.size()).build();
    }


    /**
     * 菜品总览
     * @return
     */
    @Override
    public DishOverViewVO overviewDishes() {
        // 查询已停售的套餐
        List<Dish> discontinuedDishList = dishMapper.getByStatus(Dish.DISCONTINUED);

        // 查询已起售的套餐
        List<Dish> soldDishList = dishMapper.getByStatus(Dish.SOLD);

        return DishOverViewVO.builder()
                .discontinued(discontinuedDishList.size())
                .sold(soldDishList.size()).build();
    }


    /**
     * 订单总览
     * @return
     */
    @Override
    public OrderOverViewVO overviewOrders() {
        LocalDateTime now = LocalDateTime.now();

        List<Orders> totalOrders = orderMapper.getByStatusAndOrderTimeLT(null, now);
        List<Orders> cancelledOrders = orderMapper.getByStatusAndOrderTimeLT(Orders.CANCELLED, now);
        List<Orders> completedOrders = orderMapper.getByStatusAndOrderTimeLT(Orders.COMPLETED, now);
        List<Orders> deliveredOrders = orderMapper.getByStatusAndOrderTimeLT(Orders.CONFIRMED, now);
        List<Orders> waitingOrders = orderMapper.getByStatusAndOrderTimeLT(Orders.TO_BE_CONFIRMED, now);

        return OrderOverViewVO.builder()
                .allOrders(totalOrders.size())
                .cancelledOrders(cancelledOrders.size())
                .completedOrders(completedOrders.size())
                .deliveredOrders(deliveredOrders.size())
                .waitingOrders(waitingOrders.size()).build();

    }
}
