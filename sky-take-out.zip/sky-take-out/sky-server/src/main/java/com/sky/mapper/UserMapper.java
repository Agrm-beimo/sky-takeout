package com.sky.mapper;

import com.sky.entity.User;
import com.sky.entity.UserStatistic;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDate;
import java.util.List;

@Mapper
public interface UserMapper {

    /**
     * 根据openid查询用户信息
     * @param openId
     * @return
     */
    @Select("select * from user where openid = #{openId}")
    User getByOpenId(String openId);

    /**
     * 插入新用户
     * @param user
     */
    void insert(User user);

    /**
     * 根据id查询用户
     * @param id
     * @return
     */
    @Select("select * from user where id = #{id}")
    User getById(Long id);


    /**
     * 根据日期查询用户
     * @param begin
     * @param end
     * @return
     */
    @Select("SELECT DATE(create_time) as day , COUNT(*) as amount FROM `user` WHERE create_time\n" +
            "BETWEEN #{begin} and #{end} GROUP BY day")
    List<UserStatistic> getUserListByDate(LocalDate begin, LocalDate end);


    /**
     * 查询日期之前的用户数
     * @param begin
     * @return
     */
    @Select("SELECT COUNT(*) FROM user WHERE Date(create_time) < #{begin}")
    Long getTotalUserBeforeDate(LocalDate begin);
}
