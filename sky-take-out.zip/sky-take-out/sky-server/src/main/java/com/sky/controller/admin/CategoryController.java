package com.sky.controller.admin;

import com.sky.dto.CategoryDTO;
import com.sky.dto.CategoryPageQueryDTO;
import com.sky.entity.Category;
import com.sky.result.PageResult;
import com.sky.result.Result;
import com.sky.service.CategoryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 分类管理
 */

@RestController
@RequestMapping("/admin/category")
@Api(value = "分类相关接口")
@Slf4j
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    /**
     * 分类分页查询
     * @param categoryPageQueryDTO 分页查询参数
     * @return PageResult
     */
    @GetMapping("/page")
    @ApiOperation(value = "分类分页查询")
    public Result<PageResult> page(CategoryPageQueryDTO categoryPageQueryDTO){
        log.info("分类分页查询参数：{}",categoryPageQueryDTO);
        PageResult pageResult = categoryService.pageQuery(categoryPageQueryDTO);
        return Result.success(pageResult);
    }


    /**
     * 修改分类信息
     * @param categoryDTO 修改信息
     * @return Result
     */
    @PutMapping
    @ApiOperation(value = "修改分类信息")
    public Result update(@RequestBody CategoryDTO categoryDTO){
        log.info("修改分类信息：{}",categoryDTO);
        categoryService.update(categoryDTO);
        return Result.success();
    }


    /**
     * 启用或禁用分类状态
     * @param status 状态
     * @param id id
     * @return Result
     */
    @PostMapping("/status/{status}")
    @ApiOperation(value = "启用或禁用分类状态")
    public Result startOrStop(@PathVariable Integer status ,Long id){
        log.info("员工id：{},状态修改为：{}",id,status);
        categoryService.startOrStop(status,id);
        return Result.success();
    }


    /**
     * 新增分类信息
     * @param categoryDTO 新增信息
     * @return Result
     */
    @PostMapping
    @ApiOperation(value = "新增分类信息")
    public Result save(@RequestBody CategoryDTO categoryDTO){
        log.info("新增分类信息：{}",categoryDTO);
        categoryService.save(categoryDTO);
        return Result.success();
    }

    /**
     * 根据id删除分类
     * @param id 删除的id
     * @return Result
     */
    @DeleteMapping
    @ApiOperation(value = "根据id删除分类")
    public Result deleteById(Long id){
        log.info("要删除分类的id：{}",id);
        categoryService.deleteById(id);
        return Result.success();
    }

    /**
     * 根据类型查询分类
     * @param type 分类类型
     * @return list
     */
    @GetMapping("/list")
    @ApiOperation("根据类型查询分类")
    public Result<List<Category>> list(@RequestParam Integer type){
        log.info("分类类型为：{},进行查询",type);
        List<Category> list = categoryService.list(type);
        return Result.success(list);
    }

}
