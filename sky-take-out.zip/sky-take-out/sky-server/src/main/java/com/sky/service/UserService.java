package com.sky.service;

import com.sky.dto.UserLoginDTO;
import com.sky.entity.User;

public interface UserService {

    /**
     * 微信登录
     * @param userLoginDTO 登录用户信息
     * @return User
     */
    User wxLogin(UserLoginDTO userLoginDTO);
}
