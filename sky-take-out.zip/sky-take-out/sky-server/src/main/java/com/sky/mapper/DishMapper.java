package com.sky.mapper;

import com.github.pagehelper.Page;
import com.sky.annotation.AutoFill;
import com.sky.dto.DishDTO;
import com.sky.dto.DishPageQueryDTO;
import com.sky.entity.Dish;
import com.sky.enumeration.OperationType;
import com.sky.vo.DishVO;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface DishMapper {

    /**
     * 根据分类id查询菜品数量
     * @param categoryId 分类id
     * @return 数量
     */
    @Select("SELECT COUNT(id) FROM dish WHERE category_id = #{categoryId}")
    Integer countByCategoryId(Long categoryId);

    /**
     * 新增菜品
     * @param dish 菜品信息
     */
    @AutoFill(value = OperationType.INSERT)
    void insert(Dish dish);

    /**
     * 分页查询
     * @param dishPageQueryDTO 查询参数
     * @return 查询结果
     */
    Page<DishVO> pageQuery(DishPageQueryDTO dishPageQueryDTO);


    /**
     * 根据id查询菜品信息
     * @param id id
     * @return dish
     */
    @Select("select * from dish where id = #{id}")
    Dish getById(Long id);

    /**
     * 根据id批量删除菜品
     * @param ids ids
     */
    void deleteByIds(List<Long> ids);


    /**
     * 更新菜品信息
     * @param dish 菜品信息
     */
    @AutoFill(OperationType.UPDATE)
    void update(Dish dish);

    /**
     * 查询菜品信息
     * @return
     */
    List<Dish> list(Dish dish);

    /**
     * 根据套餐id查询菜品信息
     * @param setmealId 套餐id
     * @return list
     */
    @Select("SELECT d.* FROM dish d LEFT JOIN setmeal_dish sd ON d.id = sd.dish_id WHERE sd.setmeal_id = #{setmealId}")
    List<Dish> getBySetmealId(Long setmealId);


    /**
     * 根据状态查询菜品
     * @param status
     * @return
     */
    @Select("SELECT * FROM dish WHERE status = #{status}")
    List<Dish> getByStatus(Integer status);
}
